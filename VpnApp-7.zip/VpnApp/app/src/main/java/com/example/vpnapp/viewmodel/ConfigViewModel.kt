package com.example.vpnapp.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.vpnapp.data.ConfigRepository
import com.example.vpnapp.data.VpnConfig
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.launchIn
import kotlinx.coroutines.flow.onEach
import kotlinx.coroutines.launch

enum class ConnectionState { DISCONNECTED, CONNECTING, CONNECTED, ERROR }

data class ConfigUiState(
    val configs: List<VpnConfig> = emptyList(),
    val isLoading: Boolean = false,
    val selectedConfig: VpnConfig? = null,
    val connectionState: ConnectionState = ConnectionState.DISCONNECTED,
    val errorMessage: String? = null
)

class ConfigViewModel(
    private val repository: ConfigRepository = ConfigRepository()
) : ViewModel() {

    private val _uiState = MutableStateFlow(ConfigUiState())
    val uiState: StateFlow<ConfigUiState> = _uiState.asStateFlow()

    init {
        observeConfigsLive()
    }

    /** گوش دادن زنده - با اضافه شدن کانفینگ جدید در Firestore، لیست خودکار آپدیت می‌شود */
    private fun observeConfigsLive() {
        _uiState.value = _uiState.value.copy(isLoading = true)
        repository.observeConfigs()
            .onEach { configs ->
                _uiState.value = _uiState.value.copy(configs = configs, isLoading = false)
            }
            .catch { e ->
                _uiState.value = _uiState.value.copy(isLoading = false, errorMessage = e.message)
            }
            .launchIn(viewModelScope)
    }

    /** برای دکمه رفرش دستی */
    fun refresh() {
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(isLoading = true)
            try {
                val configs = repository.fetchConfigsOnce()
                _uiState.value = _uiState.value.copy(configs = configs, isLoading = false)
            } catch (e: Exception) {
                _uiState.value = _uiState.value.copy(isLoading = false, errorMessage = e.message)
            }
        }
    }

    fun selectConfig(config: VpnConfig) {
        _uiState.value = _uiState.value.copy(selectedConfig = config)
    }

    fun setConnectionState(state: ConnectionState) {
        _uiState.value = _uiState.value.copy(connectionState = state)
    }
}
