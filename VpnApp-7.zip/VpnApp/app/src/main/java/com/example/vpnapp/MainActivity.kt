package com.example.vpnapp

import android.content.Intent
import android.net.VpnService
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import com.example.vpnapp.data.VpnConfig
import com.example.vpnapp.ui.ConfigListScreen
import com.example.vpnapp.ui.theme.VpnAppTheme
import com.example.vpnapp.viewmodel.ConfigViewModel
import com.example.vpnapp.viewmodel.ConnectionState
import com.example.vpnapp.vpn.MyVpnService

class MainActivity : ComponentActivity() {

    private val viewModel: ConfigViewModel by viewModels()
    private var pendingConfig: VpnConfig? = null

    // درخواست مجوز VPN از سیستم (دیالوگ استاندارد اندروید)
    private val vpnPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == RESULT_OK) {
            pendingConfig?.let { startVpn(it) }
        } else {
            viewModel.setConnectionState(ConnectionState.ERROR)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            VpnAppTheme {
                ConfigListScreen(
                    viewModel = viewModel,
                    onConnectClick = { config -> requestVpnPermission(config) },
                    onDisconnectClick = { stopVpn() }
                )
            }
        }
    }

    private fun requestVpnPermission(config: VpnConfig) {
        pendingConfig = config
        viewModel.setConnectionState(ConnectionState.CONNECTING)
        val intent = VpnService.prepare(this)
        if (intent != null) {
            vpnPermissionLauncher.launch(intent)
        } else {
            startVpn(config)
        }
    }

    private fun startVpn(config: VpnConfig) {
        val intent = Intent(this, MyVpnService::class.java).apply {
            action = MyVpnService.ACTION_CONNECT
            putExtra(MyVpnService.EXTRA_CONFIG_URI, config.uri)
        }
        startForegroundService(intent)
        viewModel.setConnectionState(ConnectionState.CONNECTED)
    }

    private fun stopVpn() {
        val intent = Intent(this, MyVpnService::class.java).apply {
            action = MyVpnService.ACTION_DISCONNECT
        }
        startService(intent)
        viewModel.setConnectionState(ConnectionState.DISCONNECTED)
    }
}
