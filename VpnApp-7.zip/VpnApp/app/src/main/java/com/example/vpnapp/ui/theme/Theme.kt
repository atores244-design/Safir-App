package com.example.vpnapp.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val LightColors = lightColorScheme(
    primary = PersianTurquoise,
    onPrimary = Color.White,
    secondary = PersianTurquoiseDeep,
    onSecondary = Color.White,
    background = LightBackground,
    onBackground = LightOnBackground,
    surface = LightSurface,
    onSurface = LightOnSurface,
    surfaceVariant = LightSurfaceElevated,
    onSurfaceVariant = LightOnSurfaceVariant,
    outline = LightOutline,
    error = StatusError,
)

private val DarkColors = darkColorScheme(
    primary = PersianTurquoiseBright,
    onPrimary = Color(0xFF00201D),
    secondary = PersianTurquoise,
    onSecondary = Color.White,
    background = DarkBackground,
    onBackground = DarkOnBackground,
    surface = DarkSurface,
    onSurface = DarkOnSurface,
    surfaceVariant = DarkSurfaceElevated,
    onSurfaceVariant = DarkOnSurfaceVariant,
    outline = DarkOutline,
    error = StatusError,
)

/**
 * تم اصلی اپ: پیش‌فرض روشن با فیروزه‌ای ایرانی + سفید.
 * اگر گوشی کاربر روی دارک‌مود باشد، خودکار به نسخه تیره (با همان لهجه فیروزه‌ای) سوییچ می‌کند.
 */
@Composable
fun VpnAppTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColors else LightColors
    MaterialTheme(
        colorScheme = colorScheme,
        typography = AppTypography,
        content = content
    )
}
