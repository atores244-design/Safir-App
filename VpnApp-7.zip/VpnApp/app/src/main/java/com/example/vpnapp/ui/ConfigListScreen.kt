package com.example.vpnapp.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.PowerSettingsNew
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.vpnapp.data.VpnConfig
import com.example.vpnapp.ui.theme.StatusConnected
import com.example.vpnapp.ui.theme.StatusConnecting
import com.example.vpnapp.ui.theme.StatusDisconnected
import com.example.vpnapp.ui.theme.StatusError
import com.example.vpnapp.viewmodel.ConfigViewModel
import com.example.vpnapp.viewmodel.ConnectionState

@Composable
fun ConfigListScreen(
    viewModel: ConfigViewModel,
    onConnectClick: (VpnConfig) -> Unit,
    onDisconnectClick: () -> Unit
) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()
    val colors = MaterialTheme.colorScheme

    Scaffold(
        containerColor = colors.background,
        topBar = {
            TopAppBar(
                title = { Text("Safir", fontWeight = FontWeight.Bold) },
                actions = {
                    IconButton(onClick = { viewModel.refresh() }) {
                        Icon(Icons.Filled.Refresh, contentDescription = "رفرش", tint = colors.onBackground)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = colors.background,
                    titleContentColor = colors.onBackground
                )
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 20.dp)
        ) {
            Spacer(Modifier.height(16.dp))

            ConnectButton(
                connectionState = state.connectionState,
                enabled = state.selectedConfig != null,
                onClick = {
                    val cfg = state.selectedConfig
                    if (state.connectionState == ConnectionState.CONNECTED) {
                        onDisconnectClick()
                    } else if (cfg != null) {
                        onConnectClick(cfg)
                    }
                }
            )

            Spacer(Modifier.height(28.dp))

            Text(
                "سرورها",
                style = MaterialTheme.typography.titleLarge,
                color = colors.onBackground
            )
            Spacer(Modifier.height(12.dp))

            if (state.isLoading && state.configs.isEmpty()) {
                Box(Modifier.fillMaxWidth().padding(32.dp), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator(color = colors.primary)
                }
            } else if (state.configs.isEmpty()) {
                Text("در حال حاضر کانفینگی موجود نیست", color = colors.onSurfaceVariant)
            } else {
                LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    items(state.configs) { config ->
                        ConfigCard(
                            config = config,
                            isSelected = config.id == state.selectedConfig?.id,
                            onClick = { viewModel.selectConfig(config) }
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun ConnectButton(
    connectionState: ConnectionState,
    enabled: Boolean,
    onClick: () -> Unit
) {
    val colors = MaterialTheme.colorScheme
    val (statusColor, statusText) = when (connectionState) {
        ConnectionState.CONNECTED -> StatusConnected to "متصل"
        ConnectionState.CONNECTING -> StatusConnecting to "در حال اتصال..."
        ConnectionState.ERROR -> StatusError to "خطا در اتصال"
        ConnectionState.DISCONNECTED -> StatusDisconnected to "قطع"
    }

    Column(
        modifier = Modifier.fillMaxWidth(),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(
            modifier = Modifier
                .size(140.dp)
                .clip(CircleShape)
                .background(colors.primary.copy(alpha = 0.10f))
                .border(2.dp, statusColor, CircleShape)
                .clickable(enabled = enabled) { onClick() },
            contentAlignment = Alignment.Center
        ) {
            Icon(
                Icons.Filled.PowerSettingsNew,
                contentDescription = "اتصال",
                tint = statusColor,
                modifier = Modifier.size(56.dp)
            )
        }
        Spacer(Modifier.height(10.dp))
        Text(statusText, color = statusColor, fontSize = 15.sp, fontWeight = FontWeight.Medium)
    }
}

@Composable
private fun ConfigCard(
    config: VpnConfig,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    val colors = MaterialTheme.colorScheme
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(if (isSelected) colors.surfaceVariant else colors.surface)
            .border(
                width = if (isSelected) 1.5.dp else 1.dp,
                color = if (isSelected) colors.primary else colors.outline,
                shape = RoundedCornerShape(16.dp)
            )
            .clickable { onClick() }
            .padding(16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text(config.name, color = colors.onSurface, fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
            Spacer(Modifier.height(4.dp))
            Text(config.protocol.uppercase(), color = colors.onSurfaceVariant, fontSize = 12.sp)
        }
        if (isSelected) {
            Box(
                modifier = Modifier
                    .size(10.dp)
                    .clip(CircleShape)
                    .background(colors.primary)
            )
        }
    }
}
