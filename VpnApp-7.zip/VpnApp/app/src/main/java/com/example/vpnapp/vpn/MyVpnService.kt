package com.example.vpnapp.vpn

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import android.net.VpnService
import android.os.Build
import android.os.ParcelFileDescriptor
import androidx.core.app.NotificationCompat
import com.example.vpnapp.MainActivity

/**
 * سرویس اصلی VPN. مسئول:
 * 1. باز کردن اینترفیس TUN با VpnService.Builder
 * 2. صدا زدن XrayCoreBridge برای شروع تانل واقعی
 * 3. نمایش نوتیفیکیشن foreground (اجباری برای VpnService در اندروید جدید)
 */
class MyVpnService : VpnService() {

    private var tunInterface: ParcelFileDescriptor? = null

    companion object {
        const val ACTION_CONNECT = "com.example.vpnapp.CONNECT"
        const val ACTION_DISCONNECT = "com.example.vpnapp.DISCONNECT"
        const val EXTRA_CONFIG_URI = "config_uri"
        private const val CHANNEL_ID = "vpn_channel"
        private const val NOTIF_ID = 1
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_CONNECT -> {
                val configUri = intent.getStringExtra(EXTRA_CONFIG_URI) ?: return START_NOT_STICKY
                startForeground(NOTIF_ID, buildNotification("در حال اتصال..."))
                connect(configUri)
            }
            ACTION_DISCONNECT -> {
                disconnect()
            }
        }
        return START_STICKY
    }

    private fun connect(configUri: String) {
        // ۱. اینترفیس TUN را می‌سازیم
        val builder = Builder()
            .setSession("VpnApp")
            .addAddress("10.0.0.2", 32)
            .addDnsServer("1.1.1.1")
            .addRoute("0.0.0.0", 0)
            .setMtu(1500)

        tunInterface = builder.establish()

        // ۲. هسته Xray/V2Ray را با کانفینگ انتخابی استارت می‌کنیم
        val started = XrayCoreBridge.startCore(configUri)

        updateNotification(if (started) "متصل شد" else "خطا در اتصال")
    }

    private fun disconnect() {
        XrayCoreBridge.stopCore()
        tunInterface?.close()
        tunInterface = null
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun buildNotification(text: String): Notification {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID, "وضعیت VPN", NotificationManager.IMPORTANCE_LOW
            )
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }

        val openAppIntent = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Safir")
            .setContentText(text)
            .setSmallIcon(android.R.drawable.ic_lock_lock)
            .setContentIntent(openAppIntent)
            .setOngoing(true)
            .build()
    }

    private fun updateNotification(text: String) {
        val manager = getSystemService(NotificationManager::class.java)
        manager.notify(NOTIF_ID, buildNotification(text))
    }

    override fun onDestroy() {
        disconnect()
        super.onDestroy()
    }
}
