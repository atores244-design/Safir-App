package com.example.vpnapp.data

import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.tasks.await

/**
 * منبع کانفینگ‌ها.
 * - observeConfigs(): یک Flow زنده که با هر تغییر در Firestore
 *   (اضافه/حذف/ویرایش کانفینگ) بلافاصله آپدیت می‌شود. یعنی حتی
 *   بدون فشردن دکمه رفرش هم کاربر آنلاین کانفینگ جدید را می‌بیند.
 * - fetchConfigsOnce(): برای دکمه "رفرش" دستی که کاربر لمس می‌کند.
 */
class ConfigRepository(
    private val firestore: FirebaseFirestore = FirebaseFirestore.getInstance()
) {
    private val collection = firestore.collection("configs")

    fun observeConfigs(): Flow<List<VpnConfig>> = callbackFlow {
        val registration = collection
            .whereEqualTo("isActive", true)
            .orderBy("order", Query.Direction.ASCENDING)
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    close(error)
                    return@addSnapshotListener
                }
                val configs = snapshot?.documents?.map { doc ->
                    doc.toObject(VpnConfig::class.java)?.copy(id = doc.id) ?: VpnConfig(id = doc.id)
                } ?: emptyList()
                trySend(configs)
            }
        awaitClose { registration.remove() }
    }

    suspend fun fetchConfigsOnce(): List<VpnConfig> {
        val snapshot = collection
            .whereEqualTo("isActive", true)
            .orderBy("order", Query.Direction.ASCENDING)
            .get()
            .await()
        return snapshot.documents.map { doc ->
            doc.toObject(VpnConfig::class.java)?.copy(id = doc.id) ?: VpnConfig(id = doc.id)
        }
    }
}
