package com.example.vpnapp.ui.theme

import androidx.compose.ui.graphics.Color

// رنگ اصلی برند: فیروزه‌ای ایرانی (الهام‌گرفته از کاشی‌کاری فیروزه‌ای اصفهان)
val PersianTurquoise = Color(0xFF00A99D)      // برای حالت روشن
val PersianTurquoiseBright = Color(0xFF2DD4C7) // نسخه روشن‌تر برای کنتراست روی تیره
val PersianTurquoiseDeep = Color(0xFF00767A)   // برای لهجه‌های ثانویه

// حالت روشن - سفید و فیروزه‌ای
val LightBackground = Color(0xFFFFFFFF)
val LightSurface = Color(0xFFF2FAF9)
val LightSurfaceElevated = Color(0xFFE6F5F3)
val LightOnBackground = Color(0xFF15201F)
val LightOnSurface = Color(0xFF15201F)
val LightOnSurfaceVariant = Color(0xFF5B6B69)
val LightOutline = Color(0xFFBEE7E2)

// حالت تیره - همچنان با لهجه فیروزه‌ای، بدون سیاهی مطلق
val DarkBackground = Color(0xFF121A19)
val DarkSurface = Color(0xFF1B2624)
val DarkSurfaceElevated = Color(0xFF23312E)
val DarkOnBackground = Color(0xFFF2F7F6)
val DarkOnSurface = Color(0xFFF2F7F6)
val DarkOnSurfaceVariant = Color(0xFFA9B8B6)
val DarkOutline = Color(0xFF2E4A45)

// رنگ‌های وضعیت اتصال - در هر دو تم یکسان و خوانا
val StatusConnected = Color(0xFF00A99D)
val StatusConnecting = Color(0xFFF5A623)
val StatusError = Color(0xFFE0524F)
val StatusDisconnected = Color(0xFF9AA3A2)
