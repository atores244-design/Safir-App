package com.example.vpnapp.data

/**
 * مدل یک کانفینگ که از Firestore خوانده می‌شود.
 * فیلدها باید دقیقا با نام فیلدهای سند در کالکشن "configs" یکی باشند.
 */
data class VpnConfig(
    val id: String = "",           // آی‌دی سند فایراستور (خودکار پر می‌شود)
    val name: String = "",         // نام نمایشی، مثلا "سرور آلمان ۱"
    val protocol: String = "",     // vless / vmess / trojan ...
    val uri: String = "",          // لینک کامل کانفینگ (vless://... یا vmess://...)
    val isActive: Boolean = true,  // اگر false باشد در لیست کاربر نشان داده نمی‌شود
    val order: Int = 0,            // ترتیب نمایش
    val createdAt: Long = 0L
)
