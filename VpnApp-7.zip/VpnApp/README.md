# VpnApp — اپلیکیشن تانل شخصی با کانفینگ ابری

## معماری کلی
```
┌─────────────────────┐        ┌───────────────────────┐
│   پنل مدیریت شما     │ ----> │   Firebase Firestore    │
│ (اضافه کردن کانفینگ)  │        │  collection: "configs" │
└─────────────────────┘        └──────────┬────────────┘
                                            │ realtime listener
                                            ▼
                                 ┌───────────────────────┐
                                 │   اپ اندروید کاربر      │
                                 │  Jetpack Compose UI    │
                                 │  + ConfigRepository    │
                                 │  + VpnService (Xray)   │
                                 └───────────────────────┘
```

هر بار که یک سند جدید در کالکشن `configs` در Firestore اضافه کنید،
همه کاربرانی که اپ باز دارند (یا دکمه رفرش را بزنند) کانفینگ جدید را
بلافاصله می‌بینند — چون از یک Snapshot Listener استفاده شده، نیازی به
پوش نوتیفیکیشن هم نیست.

## مراحل راه‌اندازی (باید در Android Studio انجام شود)

### ۱. ساخت پروژه Firebase
1. به [console.firebase.google.com](https://console.firebase.google.com) بروید و پروژه جدید بسازید.
2. یک اپ Android اضافه کنید (applicationId را با `app/build.gradle.kts` یکی کنید).
3. فایل `google-services.json` را دانلود و در پوشه `app/` قرار دهید.
4. در Firestore Database یک کالکشن به اسم `configs` بسازید. هر سند این ساختار را دارد:
```json
{
  "name": "سرور آلمان ۱",
  "protocol": "vless",
  "uri": "vless://uuid@host:port?params#name",
  "isActive": true,
  "order": 1,
  "createdAt": 1720000000000
}
```
برای افزودن کانفینگ جدید به‌صورت دستی می‌توانید همینجا سند بسازید،
یا از **پنل مدیریت اختصاصی** که در پوشه `admin-panel/` قرار دارد استفاده کنید
(راهنمای کامل در `admin-panel/README-admin.md`).

### ۲. اضافه کردن هسته Xray/V2Ray
این پروژه خودِ هسته تونل را کامپایل نمی‌کند (نیاز به کد Go + NDK دارد).
به جای آن، از یک کتابخانه متن‌باز آماده استفاده کنید، مثلاً:
- `AndroidLibXrayLite` (استفاده‌شده در v2rayNG)
- یا `Xray-core` binding رسمی

معمولاً این کتابخانه‌ها به‌صورت یک ماژول AAR یا JitPack dependency عرضه می‌شوند.
در فایل `vpn/XrayCoreBridge.kt` یک لایه‌ی واسط (interface) گذاشته‌ام؛
شما فقط بدنه‌ی متدهای `startCore()` و `stopCore()` را با API همان کتابخانه پر می‌کنید.
بقیه‌ی اپ (UI، مدیریت کانفینگ، VpnService، مجوزها) کامل و آماده است.

### ۳. باز کردن در Android Studio
1. پروژه را در Android Studio باز کنید (Open an existing project).
2. Gradle sync بزنید.
3. `google-services.json` را طبق مرحله ۱ اضافه کرده باشید.
4. اجرا کنید.

## ساختار فایل‌ها
- `data/VpnConfig.kt` — مدل داده کانفینگ
- `data/ConfigRepository.kt` — گرفتن لیست کانفینگ از Firestore با realtime listener
- `viewmodel/ConfigViewModel.kt` — منطق UI (لیست، رفرش، اتصال/قطع)
- `vpn/MyVpnService.kt` — سرویس VPN اندروید (VpnService) که تونل را بالا می‌آورد
- `vpn/XrayCoreBridge.kt` — لایه واسط برای وصل کردن هسته Xray/V2Ray
- `ui/ConfigListScreen.kt` — صفحه اصلی با دیزاین سفارشی (Compose)
- `ui/theme/` — رنگ‌بندی، تایپوگرافی و تم اختصاصی اپ

## شخصی‌سازی ظاهر
رنگ‌ها، فونت و شکل المان‌ها در `ui/theme/Color.kt` و `Theme.kt` است.

## اسم و آیکون اپ (Safir)
- اسم نمایشی اپ در `res/values/strings.xml` (`app_name`) روی **Safir** تنظیم شده.
- آیکون یک لترمارک هندسی حرف S (بلوکی) با پس‌زمینه گرادینت بنفش برند + یک لهجه فیروزه‌ای است:
  - `res/drawable/ic_launcher_background.xml`
  - `res/drawable/ic_launcher_foreground.xml`
  - `res/mipmap-anydpi-v26/ic_launcher.xml` و `ic_launcher_round.xml`
- **نکته:** این آیکون فقط برای اندروید ۸ (API 26) به بالا فعال است (Adaptive Icon).
  چون `minSdk` پروژه ۲۴ است، برای پوشش کامل دستگاه‌های قدیمی‌تر کافیست
  در Android Studio روی `res` کلیک راست کنید → New → Image Asset →
  همین وکتورها را انتخاب کنید تا خودش PNGهای مورد نیاز mipmap را بسازد؛
  یک کلیک و چند ثانیه کار است.
- اگر خواستید `applicationId` (پکیج) را هم از `com.example.vpnapp` به چیز دیگری
  تغییر دهید، در Android Studio از منوی Refactor → Rename Package استفاده کنید
  تا همه فایل‌ها همزمان آپدیت شوند.
